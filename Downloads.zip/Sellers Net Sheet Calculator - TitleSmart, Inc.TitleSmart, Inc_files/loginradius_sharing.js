var islrsharing = true; 
var islrsocialcounter = true;
var hybridsharing = true;