//
//  CustomPageControl.h
//  DummyKeyboardContainAppNew
//
//  Created by Jitendra Kumar on 28/11/14.
//  Copyright (c) 2014 Ankit Kumar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
@interface CustomPageControl : UIPageControl


@end
